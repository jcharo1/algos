# Code design 
I decided to use a linked list for this problem and keep track of the previous node.
# Time Efficiency
Time Efficiency for inserting blocks to the block chain take `0(1)`
Time Efficiency for this function is `O(n)` if you are searching for a specifc block because you would have to traverse the whole linked list to find block.  
# Space Complexity

Space complexity  is `O(n)`