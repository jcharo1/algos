# Code design 
For this problem I utizlied linked lists and lists. 
# Time Efficiency
Time Efficiency for this function is `O(n)`.  
# Space Complexity

Space complexity  is `O(n)`  
