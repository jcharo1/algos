# Code design 
For this problem I decided to use a min heap and dictionary to create the Huffman Tree.
# Time Efficiency
Time Efficiency for this function is `O(n log n)`. The min heap operations take O(log n) and this has to be done `n` times for each value. 
# Space Complexity
Space complexity  is `O(n)`  due being dependant on the input size.
