# Code design 
In order to search and find whether or not the file exist I have utilized a DFS appoarch with recursion to solve this problem.
# Time Efficiency
Time Efficiency for this function is `O(n)` since all sub directories are being searched in order to find all files.
# Space Complexity
Space complexity of find_files() is `O(n)` 



