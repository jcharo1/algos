# Code design 
For this problem I decided to use recursion to check if user is in groups/subgroups
# Time Efficiency
Time Efficiency for this function is `O(n)`.  
# Space Complexity

Space complexity  is `O(n)`  
