# Write your code here

# HINT: create a dictionary from flowers.txt

# HINT: create a function to ask for user's first and last name


# print the desired output

